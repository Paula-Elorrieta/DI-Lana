export interface Autoa {
    modeloa: string;
    prezioa: number;
}