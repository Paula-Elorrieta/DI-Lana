export interface QuicType {
    userId: number;
    id: number;
    title: string;
    completed: boolean;
}